This project is focusing on predicting BMI and Diabetes values using methods like LASSO regression, SVM and ohers, after cleaning and preprocessing the Data
